import spacy
from spacy.tokens import Doc
from spacy.training import Example
from spacy.language import Language
nlp = spacy.load("pl_core_news_sm")   

pred_words = ["Hoćų", "udariti", "togo", "člověka"]
pred_spaces = [True, True, True, False]
gold_words = ["Hoćų", "udariti", "togo", "člověka"]
gold_spaces = [True, True, True, False]
gold_pos = ["VERB", "VERB", "DET", "NOUN"]
gold_tags = [""]
gold_morphs = ["Aspect=Imp|Mood=Ind|Number=Sing|Person=1|Tense=Pres|VerbForm=Fin|Voice=Act", "Aspect=Perf|VerbForm=Inf|Voice=Act", "Animacy=Hum|Case=Acc|Gender=Masc|Number=Sing|PronType=Dem", "Animacy=Hum|Case=Acc|Gender=Masc|Number=Sing"]
predicted = Doc(nlp.vocab, words=pred_words, spaces=pred_spaces)
reference = Doc(nlp.vocab, words=gold_words, spaces=gold_spaces, pos=gold_pos, morphs=gold_morphs) #
my_example = Example(predicted, reference)
print(my_example)


nlp_ru = spacy.load("ru_core_news_lg")   
parsed_ru = nlp("возьми человека за руку.  убей человека")
print(parsed_ru)
for token in parsed_ru:
		   print(f"{token.text}, {token.pos_}, {token.dep_} , {token.tag_} , {token.morph}, {token.lex}, {token.sent}, {token.text}, {token.head}, {token.sentiment}")
for ent in parsed_ru.ents:
		   print(f"{ent.text}, {ent.label_}")
#for noun_chunk in parsed_ru.noun_chunks:
#		   print(f"{noun_chunk}")


def meowtest(text):
	xxx = nlp(text)
	print(xxx)
	for token in xxx:
		   print(f"{token.text}, {token.pos_}, {token.dep_} , {token.tag_} , {token.morph}, {token.lemma_}") #, {token.sent}, {token.text}, {token.head}, {token.sentiment}

#for noun_chunk in xxx.noun_chunks:
#		   print(f"{noun_chunk}")

def enttest(text):
	xxx = nlp(text)
	print(xxx)
	for ent in xxx.ents:
		   print(f"{ent.text}, {ent.label_}")
#for noun_chunk in xxx.noun_chunks:
#		   print(f"{noun_chunk}")

print("BEFORE TRAININING--------")
meowtest("Ja chcę uderzyć tego człowieka")
meowtest("Hoćų udariti togo člověka")

optimizer = nlp.initialize()

nlp.update([my_example], sgd=optimizer)
print("AFTER TRAININING--------")
meowtest("Ja chcę uderzyć tego człowieka")
meowtest("Hoćų udariti togo člověka.")