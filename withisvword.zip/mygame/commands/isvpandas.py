import json
import spacy
from spacy.matcher import Matcher
from spacy.tokens import Span, DocBin
import pandas

with open("isvwords.json", encoding="utf8") as f:
    
    TEXTS = json.loads(f.read())

pandas_text = pandas.read_json("isvwords.json")

new_texts = ''

#for criteria in pandas_text['isv']:
#    new_texts.append(' ').append(criteria)

nlp = spacy.blank("en")
matcher = Matcher(nlp.vocab)
# Add patterns to the matcher
pattern1 = ([{"LOWER": "iphone"}, {"LOWER": "x"}])
pattern2 = [{"LOWER": "iphone"}, {"IS_DIGIT": True}]
matcher.add("GADGET", [pattern1, pattern2])
docs = []
for doc in nlp.pipe("iphone x"):
    matches = matcher(doc)
    spans = [Span(doc, start, end, label=match_id) for match_id, start, end in matches]
    doc.ents = spans
    docs.append(doc)

doc_bin = DocBin(docs=docs)
doc_bin.to_disk("./train.spacy")









def isv_conjugate_word(isv_string, addition, part_of_speech, type):

    pass


def isv_conjugate_verb(isv_string, addition, part_of_speech, type):



    return {"present" : {"1.sg" : present_1sg}}

print(isv_conjugate_verb("a","a","a","a"))
print(isv_conjugate_verb("a","a","a","a")["present"])
print(isv_conjugate_verb("a","a","a","a")["present"]["1.sg"])