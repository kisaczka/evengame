
#    The hard consonants are: the labials p b f v m, the hard dentals/alveolars t d s z n r l, and the velars k g h.
 #   The soft consonants are: the postalveolars š ž č dž, the soft dentals/alveolars lj nj ŕ t́ d́ ś ź ć đ, and the palatal approximant j.
  #  The affricate c [t͡s] is pronounced hard, but in grammar it behaves like a soft consonant. Its voiced counterpart [d͡z] does not occur in Interslavic.


hard_consonants = "pbfvmtdsznrlkgh"
soft_consonants = [ 'š', 'ž', 'č' ,'dž','lj', 'nj', 'ŕ', 't́', 'd́', 'ś' ,'ź', 'ć' ,'đ','j', 'c']
pronouns_fp = ['ja','ty','on','ona','ono','my','wy','oni','one']
tenses = ["present","imperative"]
#If in the second conjugation the final consonant of the stem is s, z, t, d, st or zd, it merges with j into š, ž, č, dž, šč, ždž: prositi > pros-ju > prošu, viděti > vid-ju > vidžu. 
second_conjugation_stem_finals = ['s','z','t','d','st','zd']
second_conjugation_stem_finals_matches = {'s':'š','z':'ž','t':'č','d':'dž','st':'šč','zd':'ždž'}
#If the stem ends in k or g, it becomes č or ž before -e-. Thus: mog-eš > možeš, pek-eš > pečeš.
k_or_g_matches = {'k':'č','g':'ž'}

print("meow"[-1:])

if 'lj' in soft_consonants: print("meow")
if 'l' in hard_consonants: print("nyaa")


class isvWord:
    def __init__(self,word,pos,gender):
        self.word=word
    #    def first_conjugation(person, gender, number, tense):
   #         return {"present" : {"1.sg" : present_1sg}}





            
   #     self.meow=first_conjugation(self.word)

bibi=isvWord("WASDASDASD","WASDASDASD","WASDASDASD")
#print(bibi.meow)



def first_conjugation(verb, root, pronoun, tense):
        # Conjugate the adjective based on gender, number, and case
    if pronoun == "ja" and tense == "present":
        return(root+'ų')
    elif pronoun == "ty" and tense == "present":
        if root[-1:] == 'k' or root[-1:] == 'g': return(root[:-1]+k_or_g_matches[root[-1:]]+'eš')
        else: return(root+'eš')
    elif pronoun == "on" and tense == "present":
        if root[-1:] == 'k' or root[-1:] == 'g': return(root[:-1]+k_or_g_matches[root[-1:]]+'e')
        else:return(root+'e')
    elif pronoun == "ona" and tense == "present":
        if root[-1:] == 'k' or root[-1:] == 'g': return(root[:-1]+k_or_g_matches[root[-1:]]+'e')
        else:return(root+'e')
    elif pronoun == "ono" and tense == "present":
        if root[-1:] == 'k' or root[-1:] == 'g': return(root[:-1]+k_or_g_matches[root[-1:]]+'e')
        else:return(root+'e')
    elif pronoun == "my" and tense == "present":
        if root[-1:] == 'k' or root[-1:] == 'g': return(root[:-1]+k_or_g_matches[root[-1:]]+'emo')
        else:return(root+'emo')
    elif pronoun == "wy" and tense == "present":
        if root[-1:] == 'k' or root[-1:] == 'g': return(root[:-1]+k_or_g_matches[root[-1:]]+'ete')
        else:return(root+'ete')
    elif pronoun == "oni" and tense == "present":
        return(root+'ųt')
    elif pronoun == "one" and tense == "present":
        return(root+'ųt')

    elif pronoun == "ty" and tense == "imperative":
        if root.endswith('j'): return(root)
        else: return(root+'i')
    elif pronoun == "wy" and tense == "imperative":
        if root.endswith('j'): return(root+'te')
        else: return(root+'ite')
    elif pronoun == "my" and tense == "imperative":
        if root.endswith('j'): return(root+'mo')
        else: return(root+'imo')
    
    
    else:
        print("Invalid input.")

def second_conjugation(verb, root, pronoun, tense):
        # Conjugate the adjective based on gender, number, and case
    if pronoun == "ja" and tense == "present":
        if root[-1:] in second_conjugation_stem_finals: return(root[:-1]+second_conjugation_stem_finals_matches[root[-1:]]+'ų')
        else: return(root+'jų')
    elif pronoun == "ty" and tense == "present":
        return(root+'iš')
    elif pronoun == "on" and tense == "present":
        return(root+'i')
    elif pronoun == "ona" and tense == "present":
        return(root+'i')
    elif pronoun == "ono" and tense == "present":
        return(root+'i')
    elif pronoun == "my" and tense == "present":
        return(root+'imo')
    elif pronoun == "wy" and tense == "present":
        return(root+'ite')
    elif pronoun == "oni" and tense == "present":
        return(root+'et')
    elif pronoun == "one" and tense == "present":
        return(root+'et')

    elif pronoun == "ty" and tense == "imperative":
        if root.endswith('j'): return(root)
        else: return(root+'i')
    elif pronoun == "wy" and tense == "imperative":
        if root.endswith('j'): return(root+'te')
        else: return(root+'ite')
    elif pronoun == "my" and tense == "imperative":
        if root.endswith('j'): return(root+'mo')
        else: return(root+'imo')
    
    
    else:
        print("Invalid input.")




print(second_conjugation("viděti","vid","ja","present"))
for i in pronouns_fp: print(first_conjugation("mogti","mog",i,"present"))


def conjugate_verb(verb,pronoun,tense):

    """
    First conjugation:
        when the infinitive stems ends in a consonant, the present tense stem is identical to it: nesti > nes-, vezti > vez-, klasti (< klad-ti) > klad-
        verbs on -ati, monosyllabic stems ending in a vowel, and a number of verbs on -ěti have -j- added to the infinitive stem: dělati > dělaj-, uměti > uměj-, biti > bij-, čuti > čuj-
        verbs on -ovati have a present-tense stem -uj-: kovati > kuj-, organizovati > organizuj-
        verbs on -nuti have a present-tense stem -n-: tegnuti > tegn-, dvignuti > dvign-
    Second conjugation:
        verbs on -iti and most verbs on -ěti have the present tense stem -i-: hvaliti > hval-i- „to praise”, viděti > vid-i- „to see” 
    """
    # Define the verb and its endings
    stem = verb[:-2]
    if stem[-1:] in hard_consonants or stem[-1:] in soft_consonants:
        root = stem

        for pn in pronouns_fp:
            for ten in tenses:
                setattr(self, pronoun+tense, first_conjugation(verb,root,pronoun,tense))

        
        present_sg_2 = root + "aš"
        present_sg_3_masc = root + "a"
        present_sg_3_fem = root + "a"
        present_sg_3_neut = root + "a"
        present_pl_1 = root + "amo"
        present_pl_2 = root + "ate"
        present_pl_3 = root + "aju"
        past_sg_masc = root + "al"
        past_sg_fem = root + "ala"
        past_sg_neut = root + "alo"
        past_pl = root + "ali"
        active_participle = root + "ajųći"
        passive_participle = root + "an"

    if verb.endswith("nuti"):
        root = verb[:-3]
        present_sg_1 = root + "am"
        present_sg_2 = root + "aš"
        present_sg_3_masc = root + "a"
        present_sg_3_fem = root + "a"
        present_sg_3_neut = root + "a"
        present_pl_1 = root + "amo"
        present_pl_2 = root + "ate"
        present_pl_3 = root + "aju"
        past_sg_masc = root + "al"
        past_sg_fem = root + "ala"
        past_sg_neut = root + "alo"
        past_pl = root + "ali"
        active_participle = root + "ajųći"
        passive_participle = root + "an"
    elif verb.endswith("ati"):
        root = stem+'j'
        present_sg_1 = root + "u"
        present_sg_2 = root + "aš"
        present_sg_3_masc = root + "a"
        present_sg_3_fem = root + "a"
        present_sg_3_neut = root + "a"
        present_pl_1 = root + "amo"
        present_pl_2 = root + "ate"
        present_pl_3 = root + "aju"
        past_sg_masc = root + "al"
        past_sg_fem = root + "ala"
        past_sg_neut = root + "alo"
        past_pl = root + "ali"
        active_participle = root + "ajųći"
        passive_participle = root + "an"
    elif verb.endswith("ovati"):
        root = verb[:-5]+'uj'
        present_sg_1 = root + "am"
        present_sg_2 = root + "aš"
        present_sg_3_masc = root + "a"
        present_sg_3_fem = root + "a"
        present_sg_3_neut = root + "a"
        present_pl_1 = root + "amo"
        present_pl_2 = root + "ate"
        present_pl_3 = root + "aju"
        past_sg_masc = root + "al"
        past_sg_fem = root + "ala"
        past_sg_neut = root + "alo"
        past_pl = root + "ali"
        active_participle = root + "ajųći"
        passive_participle = root + "an"

    #second declension
    elif verb.endswith("iti"):
        root = verb[:-3]
        present_sg_1 = root + "im"
        present_sg_2 = root + "iš"
        present_sg_3_masc = root + "i"
        present_sg_3_fem = root + "i"
        present_sg_3_neut = root + "i"
        present_pl_1 = root + "imo"
        present_pl_2 = root + "ite"
        present_pl_3 = root + "jųt"
        past_sg_masc = root + "il"
        past_sg_fem = root + "ila"
        past_sg_neut = root + "ilo"
        past_pl = root + "ili"
        active_participle = root + "ęći"
        passive_participle = root + "en"
    elif verb.endswith("ěti"):
        root = verb[:-3]
        present_sg_1 = root + "im"
        present_sg_2 = root + "iš"
        present_sg_3_masc = root + "i"
        present_sg_3_fem = root + "i"
        present_sg_3_neut = root + "i"
        present_pl_1 = root + "imo"
        present_pl_2 = root + "ite"
        present_pl_3 = root + "jųt"
        past_sg_masc = root + "il"
        past_sg_fem = root + "ila"
        past_sg_neut = root + "ilo"
        past_pl = root + "ili"
        active_participle = root + "ęći"
        passive_participle = root + "en"
    else:
        print("Invalid verb.")

    # Ask for number and case
    number = input("Enter the number (sg, pl): ")
    case = input("Enter the case (nom, gen, dat, acc, loc, voc): ")

    # Conjugate the verb based on number and case
    if number == "sg" and case == "nom":
        return(present_sg_3_masc)
    elif number == "sg" and case == "gen":
        return(past_sg_masc + "a")
    elif number == "sg" and case == "dat":
        return(past_sg_masc + "u")
    elif number == "sg" and case == "acc":
        return(past_sg_masc)
    elif number == "sg" and case == "loc":
        return(past_sg_masc + "u")
    elif number == "sg" and case == "voc":
        return(present_sg_3_masc + "e")
    elif number == "pl" and case == "nom":
        return(present_pl_3_masc)
    elif number == "pl" and case == "gen":
        return(past_pl_masc + "a")
    elif number == "pl" and case == "dat":
        return(past_pl_masc + "u")
    elif number == "pl" and case == "acc":
        return(past_pl_masc)
    elif number == "pl" and case == "loc":
        return(past_pl_masc + "u")
    elif number == "pl" and case == "voc":
        return(present_pl_3_masc + "e")
















# Define function to conjugate pronoun
def conjugate_pronoun(pronoun, case):
    # Define pronoun and case
    pronoun = "ja"
    case = "gen"

    # Define endings for each case
    endings = {"nom": "ja", "gen": "mene", "dat": "mně", "acc": "mja", "loc": "mnie", "ins": "mnou", "voc": ""}

    return pronoun + endings[case]


# Define function to conjugate noun
def conjugate_noun(noun, gender, case):
    # Test the function
    

    # Define noun and gender
    noun = "stol"
    gender = "masc"

    # Define endings for each gender
    masc_endings = {"nom": "", "gen": "a", "dat": "u", "acc": "", "loc": "u", "ins": "om", "voc": ""}
    fem_endings = {"nom": "a", "gen": "e", "dat": "i", "acc": "u", "loc": "i", "ins": "om", "voc": "o"}

    if gender == "masc":
        return noun + masc_endings[case]
    elif gender == "fem":
        return noun + fem_endings[case]
    else:
        return "Invalid gender"


print(conjugate_pronoun('ja', 'nom')) # Output: mene
# Test the function
print(conjugate_noun("stol", 'm', "nom")) # Output: stol
print(conjugate_noun("dver", 'm', "gen")) # Output: stola


def conjugate_adjective(adjective, number, case, gender):

    # Define the adjective and its endings
    nom_sg_masc = adjective[:-2] + "y"
    nom_sg_fem = adjective[:-2] + "a"
    nom_sg_neut = adjective[:-2] + "o"
    gen_sg = adjective[:-2] + "ogo"
    dat_sg = adjective[:-2] + "omu"
    acc_sg_masc = adjective[:-2] + "ego"
    acc_sg_fem = adjective[:-2] + "u"
    acc_sg_neut = adjective[:-2] + "o"
    inst_sg_masc = adjective[:-2] + "ym"
    inst_sg_fem = adjective[:-2] + "ojų"
    inst_sg_neut = adjective[:-2] + "ym"
    pre_sg_masc = adjective[:-2] + "om"
    pre_sg_fem = adjective[:-2] + "ojų"
    pre_sg_neut = adjective[:-2] + "om"

    # Ask for gender, number, and case
  #  gender = input("Enter the gender (masc, fem, neut): ")
  #  number = input("Enter the number (sg, pl): ")
   # case = input("Enter the case (nom, gen, dat, acc, inst, pre): ")

    # Conjugate the adjective based on gender, number, and case
    if gender == "masc" and number == "sg" and case == "nom":
        print(nom_sg_masc)
    elif gender == "fem" and number == "sg" and case == "nom":
        print(nom_sg_fem)
    elif gender == "neut" and number == "sg" and case == "nom":
        print(nom_sg_neut)
    elif number == "sg" and case == "gen":
        print(gen_sg)
    elif number == "sg" and case == "dat":
        print(dat_sg)
    elif gender == "masc" and number == "sg" and case == "acc":
        print(acc_sg_masc)
    elif gender == "fem" and number == "sg" and case == "acc":
        print(acc_sg_fem)
    elif gender == "neut" and number == "sg" and case == "acc":
        print(acc_sg_neut)
    elif gender == "masc" and number == "sg" and case == "inst":
        print(inst_sg_masc)
    elif gender == "fem" and number == "sg" and case == "inst":
        print(inst_sg_fem)
    elif gender == "neut" and number == "sg" and case == "inst":
        print(inst_sg_neut)
    elif number == "sg" and case == "pre":
        print(pre_sg)
    else:
        print("Invalid input.")



