import pandas
import json

import json

# Open the JSON file
with open('basic.json', 'r') as f:
    # Load the JSON data
    isv_data = json.load(f)

# Access the data
#print(isv_data['searchIndex']['isv-src'][1][1])
  

counts_set = set()
counts_dict = {}
counts_list = []

# Iterating through the json
# list
for word in isv_data['searchIndex']['isv-src']:
    counts_set.add(len(word[1]))
    counts_list.append(len(word[1]))

    if len(word[1]) <5:
        print(word[1])

for i in range(0,100):
    print(f'{i} :: {counts_list.count(i)}')
  





