import spacy
import random
from spacy import util
from spacy.tokens import Doc
from spacy.training import Example
from spacy.language import Language
#Hoćų udariti togo člověka


def print_doc_entities(_doc: Doc):
    if _doc.ents:
        for _ent in _doc.ents:
            print(f"     {_ent.text} {_ent.label_}")
    else:
        print("     NONE")


def meowtest(text,nlp):
	nlp_text = nlp(text)
	print(nlp_text)
	for token in nlp_text:
		   print(f"{token.text}, {token.pos_}, {token.dep_} , {token.tag_} , {token.morph}, {token.lemma_}") #, {token.sent}, {token.text}, {token.head}, {token.sentiment}
	for ent in nlp_text.ents:
		   print(f"{ent.text}, {ent.label_}")
#for noun_chunk in nlp_text.noun_chunks:
#		   print(f"{noun_chunk}")


def customizing_pipeline_component(nlp: Language, test_example):
    # NOTE: Starting from Spacy 3.0, training via Python API was changed. For information see - https://spacy.io/usage/v3#migrating-training-python
    train_data = [
        ('We need to deliver it to Festy.', [(25, 30, 'DISTRICT')]), #raw_text, entity_offsets
        ('I like red oranges', [])
    ]
    test_data = "Hoćų udariti togo člověka"#Ja hoćų idti k domu.

    # Result before training
    print(f"\nResult BEFORE training:")
    doc = nlp(test_data)
    meowtest(test_data,nlp)
    print_doc_entities(doc)








    

    # Disable all pipe components except 'ner'
    disabled_pipes = []
    for pipe_name in nlp.pipe_names:
        print(pipe_name)
        if pipe_name != 'ner':
            nlp.disable_pipes(pipe_name)
            disabled_pipes.append(pipe_name)

    print("   Training ...")
    optimizer = nlp.create_optimizer()
    for _ in range(25):
        random.shuffle(train_data)
        for raw_text, entity_offsets in train_data:
            doc = nlp.make_doc(raw_text)
            example = test_example#Example.from_dict(doc, {"entities": entity_offsets})
            nlp.update([example], sgd=optimizer)

    # Enable all previously disabled pipe components
    for pipe_name in disabled_pipes:
        nlp.enable_pipe(pipe_name)

    # Result after training
    print(f"Result AFTER training:")
    doc = nlp(test_data)
    meowtest(test_data,nlp)
    print_doc_entities(doc)

def main():
    nlp = spacy.load('pl_core_news_sm')

    pred_words = ["Hoćų", "udariti", "togo", "člověka"]
    pred_spaces = [True, True, True, False]
    gold_words = ["Hoćų", "udariti", "togo", "člověka"]
    gold_spaces = [True, True, True, False]
    gold_tags = ["VERB", "VERB", "DET", "NOUN"]
    gold_morphs = ["Aspect=Imp|Mood=Ind|Number=Sing|Person=1|Tense=Pres|VerbForm=Fin|Voice=Act", "Aspect=Perf|VerbForm=Inf|Voice=Act", "Animacy=Hum|Case=Acc|Gender=Masc|Number=Sing|PronType=Dem", "Animacy=Hum|Case=Acc|Gender=Masc|Number=Sing"]
    predicted = Doc(nlp.vocab, words=pred_words, spaces=pred_spaces)
    reference = Doc(nlp.vocab, words=gold_words, spaces=gold_spaces, tags=gold_tags, morphs=gold_morphs)
    my_example = Example(predicted, reference)
    print(my_example)

    customizing_pipeline_component(nlp,my_example)


def generate_examples():
    

if __name__ == '__main__':
    main()