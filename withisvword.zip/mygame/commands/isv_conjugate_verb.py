import re
prefixes = [   'do', 'iz', 'izpo', 'nad', 'na', 'ne', 'ob', 'odpo', 'od', 'o', 'prědpo', 'pod', 'po', 'prě', 'pre', 'pri', 'pro', 'råzpro', 'razpro', 'råz', 'raz', 'sȯ', 's', 'u', 'vȯ', 'vo', 'v', 'vȯz', 'voz', 'vy', 'za']

irregular_stems = {'da': 1, 'je': 1, 'jě': 1, 'ja': 1, 'vě': 1}

def conjugationVerbFlat(inf, rawPts):
    return getConjugationVerbFlat(conjugationVerb(inf, rawPts))

def getConjugationVerbFlat(result):
    if not result:
        return []
    forms = [
        *list(filter(None, map(lambda item: item.split(' ')[1].replace(/[()]/g, ''), result['conditional']))),
        result['gerund'],
        *result['imperative'].replace(' ', '').split(','),
        *result['imperfect'],
        result['infinitive'],
        *re.split('[(),]', result['pfap'].replace(/[(),]/g, '')),
        *re.split('[(),]', result['pfpp'].replace(/[(),]/g, '')),
        *re.split('[(),]', result['prap'].replace(/[(),]/g, '')),
        *re.split('[(),]', result['prpp'].replace(/[(),]/g, '')),
        *re.split(',', result['present'].join(',').replace(' ', ''))
    ]
    forms = list(filter(None, forms))
    forms = list(filter(lambda item: '-' not in item, forms))
    return list(set(forms))

def conjugationVerb(inf, rawPts):
    #special cases
    if '/' in inf.split(' ')[0]:
        return None
    if inf == 'sųt' or inf == 'je' or inf == 'jest':
        inf = 'byti'
    pts = re.split('[;,/]', rawPts.replace(') (', ')(').replace(/[()]/g, ''))[0].replace('+d','')
    refl = reflexive(inf)
    pref = prefix(inf)
    is_ = infinitive_stem(pref, inf, pts)
    ps = present_tense_stem(pref, pts, is_)
    psi = secondary_present_tense_stem(ps)
    lpa = l_participle(pref, pts, is_)
    infinitive = build_infinitive(pref, is_, refl)
    present = buildPresent(pref, ps, psi, refl)
    imperfect = build_imperfect(pref, is_, refl)
    perfect = buildPerfect(lpa, refl)
    pluperfect = buildPluralPerfect(lpa, refl)
    future = buildFuture(infinitive, ps)
    conditional = buildConditional(lpa, refl)
    imperative = build_imperative(pref, psi, refl)
    prap = build_prap(pref, ps, refl)
    prpp = build_prpp(pref, ps, psi)
    pfap = build_pfap(lpa, refl)
    pfpp = build_pfpp(pref, is_, psi)
    gerund = build_gerund(pfpp, refl)

    return {
'infinitive': infinitive,
'present': present,
'imperfect': imperfect,
'perfect': perfect,
'pluperfect': pluperfect,
'future': future,
'conditional': conditional,
'imperative': imperative,
'prap': prap,
'prpp': prpp,
'pfap': pfap,
'pfpp': pfpp,
'gerund': gerund
}

def reflexive(inf):
    result = ''
    if inf.index(' ') != -1 and inf.split(' ')[1] in ['se', 'sę']:
        result = ' sę'
    else:
        result = ''
    return result

def prefix(inf):
    prefArr = list(filter(
        lambda prfx: inf.index(prfx) == 0 and
        inf.split(' ')[0][len(prfx):] in ['věděti', 'vedeti', 'jesti', 'jěsti', 'dati', 'dųti', 'byti', 'žegti'],
        prefixes))
    if len(prefArr) > 0:
        return prefArr[0]
    kreska = inf.index('-')
    if kreska != -1:
        return inf[:kreska + 1]
    if inf.index('ne ') == 0:
        return 'ne '
    return ''

def infinitive_stem(pref, inf, pts):
    trunc = ''
    result = ''

    inf = inf.replace(pref, '')

    if len(inf) == 0:
        result = 'ERROR-1'
        return result

    elif inf.find(' ') != -1:
        trunc = inf[:inf.index(' ')]
    else:
        trunc = inf

    if trunc == '':
        result = 'ERROR-2'
        return result

    valid_endings = ['ti', 'tì', 't', 'ť']
    for element in valid_endings:
        length = len(element)
        if trunc[-length:] == element:
            result = trunc[:-length]
            break

    if result == "":
        result = 'ERROR-2'
        return result

    if result[-1] == 's':
        # *jesti
        if result == 'jes':
            result = 'jed'
        # stem based on present tense stem
        elif pts:
            result = pts[:-1]
    return result

def derive_present_tense_stem(infinitive_stem_string):
    # Note that sometimes a special character ĵ is inserted into the string
    # Naučny Medžuslovjanski uses...
    # ...ĵ in cases where most Slavic languages have contraction -aje- > -a-
    result = infinitive_stem_string

    if ['ova', 'eva'].__contains__(result[-3:]) and result != 'hova':
        result = result[:-3] + 'uj'
    elif len(result) > 3 and result[-2:] in ['nu', 'nų']:
        result = result[:-1]
    elif result[-1] == 'ę':
        if result[-2:] == 'ję':
            if result[-3:] in ['bję', 'dję', 'sję', 'zję']:
                result = result[:-2] + 'ȯjm'
            else:
                result = result[:-1] + 'm'
        elif result == 'vzę':
            result = 'vȯzm'
        else:
            result = result[:-1] + 'n'
    elif result[-1] == 'ų':
        result = result[:-1]
    elif len(result) < 4 and result[-1] in ['y', 'o', 'u', 'e', 'ě']:
        if result[0] == 'u':
            result += 'ĵ'
        else:
            result += 'j'
    elif result[-1] in ['a', 'e', 'ě']:
        result += 'ĵ'
    return result

def present_tense_stem(pref, pts, is_):
    result = is_
    if len(pts) == 0:
        result = derive_present_tense_stem(is_)
    else:
        if (pts[-2:] == 'se' or pts[-2:] == 'sę') and len(pts) > 2:
            pts = pts[:-3]
        elif pts.startswith('se ') or pts.startswith('sę '):
            pts = pts[3:]
        if len(pref) != 0:
            if pref in pts:
                pts = pts[len(pref):]
            else:
                pts = pts[len(pref)-1:]
        if pts.endswith('-') or pts.endswith('m') or pts.endswith('e') or pts.endswith('ų') or pts.endswith('u'):
            result = pts[:-1]
        else:
            result = pts
    result = process_present_tense_stem_exceptions(pref, pts, is_, result)
    return result


def process_present_tense_stem_exceptions(pref, pts, is_, result):
    if (is_ == 'by' and pref == '') or ((result == 'je' or result == 'j') and is_ == 'bi'):
        result = 'jes'
    elif result == 'věděĵ':
        result = 'vě'
    elif (result == 'jed' or result == 'j') and is_ == 'jed':
        result = 'je'
    elif (result == 'jěd' or result == 'j') and is_ == 'jěd':
        result = 'jě'
    elif (result == 'jad' or result == 'j') and is_ == 'jad':
        result = 'ja'
    elif result == 'daĵ':
        result = 'da'
    elif result == 'žeg' or result == 'žž':
        result = 'žg'
    if (result == 'jěhaĵ') or ((result == 'jě') and (is_ == 'jěha')):
        result = 'jěd'
    if (result == 'jehaĵ') or ((result == 'je') and (is_ == 'jeha')):
        result = 'jed'
    if (result == 'jahaĵ') or ((result == 'ja') and (is_ == 'jaha')):
        result = 'jad'
    return result

import re

def secondary_present_tense_stem(ps):
    return re.sub('g$', 'ž', re.sub('k$', 'č', ps))

def l_participle(pref, pts, is_):
    if is_ == 'vojd' or is_ == 'vȯjd':
        result = 'všėl'
    elif is_ == 'id' or is_ == 'jd':
        result = pref + 'šėl'
    elif is_[-2:] == 'id' or is_[-2:] == 'jd':
        result = pref + is_[:-2] + 'šėl'
    elif re.match(r'r[eě]$', is_) and re.match(r're$', pts):
        result = pref + is_[:-2] + 'ŕl'
    else:
        result = pref + is_ + 'l'
    return result

def build_infinitive(pref, is_, refl):
    if is_[-2:] == 'st':
        is_ = is_[:-1]
    elif is_[-1:] == 't' or re.match(r'[^ij]d$', is_):
        is_ = is_[:-1] + 's'
    return transliterateBack(pref + is_ + 'tì' + refl)

def buildPresent(pref, ps, psi, refl):
    # see: irregular_stems
    if ps == 'jes':
        return list(map(transliterateBack, ['jesm', 'jesi', 'jest (je)', 'jesmȯ', 'jeste', 'sųt']))
    elif ps == 'da':
        return list(map(lambda word: transliterateBack(f'{pref}{word}{refl}'), ['dam', 'daš', 'da', 'damȯ', 'date', 'dadųt']))
    elif ps == 'vě':
        return list(map(lambda word: transliterateBack(f'{pref}{word}{refl}'), ['věm', 'věš', 'vě', 'věmȯ', 'věte', 'vědųt']))
    elif ps == 'jě':
        return list(map(lambda word: transliterateBack(f'{pref}{word}{refl}'), ['jěm', 'jěš', 'jě', 'jěmȯ', 'jěte', 'jědųt']))
    elif ps == 'je':
        return list(map(lambda word: transliterateBack(f'{pref}{word}{refl}'), ['jem', 'ješ', 'je', 'jemȯ', 'jete', 'jedųt']))
    elif ps == 'ja':
        return list(map(lambda word: transliterateBack(f'{pref}{word}{refl}'), ['jam', 'jaš', 'ja', 'jamȯ', 'jate', 'jadųt']))
    
    if ps[-1] == 'ĵ':
        # Naučny Medžuslovjanski uses...
        # ...ĵ in cases where most Slavic languages have contraction -aje- > -a-
        cut = ps[:-1]
        pps = f'{cut}j'
        return list(map(transliterateBack, [
            f'{pref}{pps}ų{refl}, {pref}{cut}m{refl}', 
            f'{pref}{pps}eš{refl}, {pref}{cut}š{refl}', 
            f'{pref}{pps}e{refl}, {pref}{cut}{refl}', 
            f'{pref}{pps}emȯ{refl}, {pref}{cut}mo{refl}', 
            f'{pref}{pps}ete{refl}, {pref}{cut}te{refl}', 
            f'{pref}{pps}ųt{refl}'
        ]))
    elif ps[-1] == 'i':
        cut = ps[:-1]
        return list(map(transliterateBack, [
            f'{pref}{cut}xų{refl}, {pref}{ps}m{refl}',
            f'{pref}{ps}š{refl}',
            f'{pref}{ps}{refl}',
            f'{pref}{ps}mȯ{refl}',
            f'{pref}{ps}te{refl}',
            f'{pref}{cut}ęt{refl}'
        ]))
    else:
        return list(map(transliterateBack, [
            f'{pref}{ps}ų{refl}, {pref}{psi}em{refl}',
            f'{pref}{psi}eš{refl}',
            f'{pref}{psi}e{refl}',
            f'{pref}{psi}emȯ{refl}',
            f'{pref}{psi}ete{refl}',
            f'{pref}{ps}ųt{refl}'
        ]))

def build_imperfect(pref, is_, refl):
    impst = ''
    i = len(is_) - 1
    if not is_[i].lower() in ['a', 'e', 'i', 'o', 'u', 'y', 'ę', 'ų', 'å', 'ě', 'ė', 'ȯ']:
        if is_[i] == 'k':
            impst = is_[:i] + 'če'
        elif is_[-3:] == 'žeg':
            impst = 'žže'
        elif is_[i] == 'g':
            impst = is_[:i] + 'že'
        else:
            impst = is_ + 'e'
    elif is_ == 'by' and pref == '':
        impst = 'bě'
    else:
        impst = is_

    return [
        f"{pref}{impst}h{refl}",
        f"{pref}{impst}še{refl}",
        f"{pref}{impst}še{refl}",
        f"{pref}{impst}hmȯ{refl}",
        f"{pref}{impst}ste{refl}",
        f"{pref}{impst}hų{refl}",
    ]

def buildFuture(infinitive, ps):
    if infinitive.lower() in ['biti', 'бити'] and ps.lower() in ['j', 'je', 'jes'] or infinitive.lower() in ['byti', 'bytì', 'быти']:
        infinitive = ''
    verb = transliterateBack(infinitive)
    return [
        f"bųdų {verb}",
        f"bųdeš {verb}",
        f"bųde {verb}",
        f"bųdemȯ {verb}",
        f"bųdete {verb}",
        f"bųdųt {verb}",
    ]

def buildPerfect(lpa, refl):
    result = [
        f'jesm {lpa}(a){refl}',
        f'jesi {lpa}(a){refl}',
        f'(je) {lpa}{refl}',
        f'(je) {lpa}a{refl}',
        f'(je) {lpa}o{refl}',
        f'jesmȯ {lpa}i{refl}',
        f'jeste {lpa}i{refl}',
        f'(sųt) {lpa}i{refl}',
        ''
    ]

    return list(map(lambda line: transliterateBack(zegti(idti(line)) if 'žegl' in line else idti(line)), result))


def buildPluralPerfect(lpa, refl):
    result = [
        f'běh {lpa}(a){refl}',
        f'běše {lpa}(a){refl}',
        f'běše {lpa}{refl}',
        f'běše {lpa}a{refl}',
        f'běše {lpa}o{refl}',
        f'běhmo {lpa}i{refl}',
        f'běste {lpa}i{refl}',
        f'běhų {lpa}i{refl}',
        ''
    ]

    return list(map(lambda line: transliterateBack(zegti(idti(line)) if 'žegl' in line else idti(line)), result))


def buildConditional(lpa, refl):
    result = [
        f'byh {lpa}(a){refl}',
        f'bys {lpa}(a){refl}',
        f'by {lpa}{refl}',
        f'by {lpa}a{refl}',
        f'by {lpa}o{refl}',
        f'byhmȯ {lpa}i{refl}',
        f'byste {lpa}i{refl}',
        f'by {lpa}i{refl}',
        ''
    ]

    return list(map(lambda line: transliterateBack(zegti(idti(line)) if 'žegl' in line else idti(line)), result))

def build_imperative(pref, ps, refl):
    p2s = ''
    i = len(ps) - 1

    if ps == 'jes':
        p2s = 'bųď'
    elif ps == 'da':
        # this irregular stem is handled slightly differently
        p2s = pref + ps + 'j'
    elif ps in irregular_stems:
        p2s = pref + ps + 'ď'
    elif ps[i] == 'ĵ' or ps[i] == 'j':
        p2s = pref + ps
    elif ps[i] == 'a' or ps[i] == 'e' or ps[i] == 'ě':
        p2s = pref + ps + 'j'
    elif ps[i] == 'i':
        p2s = pref + ps
    else:
        p2s = pref + ps + 'i'

    result = p2s + refl + ', ' + p2s + 'mȯ' + refl + ', ' + p2s + 'te' + refl
    result = result.replace('jij', 'j')
    result = result.replace('ĵij', 'ĵ')
    result = transliterateBack(result)
    return result


def build_prap(pref, ps, refl):
    # Present Participle Active (napr., izslědujuči)
    cut = ''
    i = len(ps) - 1

    if ps == 'jes':
        ps = pref + 'sų'
    elif ps in irregular_stems:
        ps = pref + ps + 'dų'
    elif ps[i] == 'a' or ps[i] == 'e' or ps[i] == 'ě':
        ps = pref + ps + 'jų'
    elif ps[i] == 'i':
        cut = ps[:-1]
        ps = pref + cut + 'ę'
    else:
        ps = pref + ps + 'ų'

    return transliterateBack(ps + 'ćí (' + ps + 'ćá, ' + ps + 'ćé)' + refl)

def build_prpp(pref, ps, psi):
    # Present Participle Passive (napr., izslědujemy)
    result = ''

    if ps == 'jes':
        result = '—'
    elif ps in irregular_stems:
        ps = ps + 'do'

    i = (len(ps) - 1)
    cut = ''
    if ps[i] == 'ĵ':
        cut = ps[:i]
        ps = cut + 'j'
        result = pref + ps + 'emý (—á, —œ)' + ', ' + pref + cut + 'mý (—á, —œ)'
    elif ps[i] == 'j':
        result = pref + psi + 'emý (' + pref + psi + 'emá, ' + pref + psi + 'emœ)'
    elif (ps[i] == 's') or (ps[i] == 'z') or (ps[i] == 't') or (ps[i] == 'd') or (ps[i] == 'l'):
        result = pref + ps + 'omý (' + pref + ps + 'omá, ' + pref + ps + 'omœ)'
    elif (ps[i] == 'i') or (ps[i] == 'o'):
        result = pref + ps + 'mý (' + pref + ps + 'má, ' + pref + ps + 'mœ)'
    elif result != '—':
        result = pref + psi + 'emý (' + pref + psi + 'emá, ' + pref + psi + 'emœ)'

    result = transliterateBack(result)
    return result


def build_pfap(lpa, refl):
    # Past Participle Active (napr., izslědovavši)
    result = ''
    if lpa[-2] in ['a', 'e', 'i', 'o', 'u', 'y', 'ę', 'ų', 'å', 'ě', 'ė', 'ȯ']:
        result = lpa[:-1] + 'vši' + refl
    else:
        result = lpa[:-1] + 'ši' + refl
    if 'šėv' in result:
        result = idti(result)
    result = result + ' (' + result[:-1] + "á, " + result[:-1] + "é)"
    result = transliterateBack(result)
    return result


def build_pfpp(pref, is, psi):
    # Past Participle Passive (napr., izslědovany)
    ppps = ''
    i = (len(is) - 1)
    # rule for -t by Ranmaru Rei
    if re.match(r'r[eě]$', is) and re.match(r'r$', psi):
        ppps = pref + is[:-2] + 'ŕt'
    elif (
        re.match(r'[iyuě]$', is) and re.match(r'[jvn]$', psi) and psi != 'imaj' or
        re.match(r'[ęuųå]$', is) or
        is == 'by' or
        re.match(r'lě$', is) and re.match(r'lj$', psi)
    ):
        ppps = pref + is + 't'
    elif (is[i] == 'a') or (is[i] == 'e') or (is[i] == 'ě'):
        ppps = pref + is + 'n'
    elif is[i] == 'i':
        ppps = pref + is + 'Xen'
        ppps = ppps.replace('stiX', 'šćX')
        ppps = ppps.replace('zdiX', 'žđX')
        ppps = ppps.replace('siX', 'šX')
        ppps = ppps.replace('ziX', 'žX')
        ppps = ppps.replace('tiX', 'ćX')
        ppps = ppps.replace('diX', 'đX')
        ppps = ppps.replace('jiX', 'jX')
        ppps = ppps.replace('šiX', 'šX')
        ppps = ppps.replace('žiX', 'žX')
        ppps = ppps.replace('čiX', 'čX')
        ppps = ppps.replace('iX', 'jX')
        ppps = ppps.replace('X', '')
    elif (is[i] == 'k') or (is[i] == 'g'):
        if psi[-1] == 'i':
            ppps = pref + psi[:-1] + 'en'
        else:
            ppps = pref + psi + 'en'
    else:
        ppps = pref + is + 'en'

    return transliterateBack(ppps + 'ý (' + ppps + 'á, ' + ppps + 'ó)')

def build_gerund(pfpp, refl):
    ppps = pfpp.index('(') - 2
    return transliterateBack(pfpp[:ppps] + 'ıje' /*+ refl*/)

def idti(sel):
    return sel \
        .replace('šėl(a)', 'šėl/šla') \
        .replace('šėl(a)', 'šėl/šla') \
        .replace('všėl/šla', 'všėl/vȯšla') \
        .replace('všėl/šla', 'všėl/vȯšla') \
        .replace('šėla', 'šla') \
        .replace('šėlo', 'šlo') \
        .replace('šėli', 'šli') \
        .replace('všl', 'vȯšl') \
        .replace('iz[oȯ]š', 'izš') \
        .replace('ob[oȯ]š', 'obš') \
        .replace('od[oȯ]š', 'odš') \
        .replace('pod[oȯ]š', 'podš') \
        .replace('nad[oȯ]š', 'nadš')

def zegti(zeg):
    return zeg \
        .replace('žegl(a)$', 'žegl/žgla') \
        .replace('žegla$', 'žgla') \
        .replace('žeglo$', 'žglo') \
        .replace('žegli$', 'žgli')

def transliterateBack(iW):
    return iW \
        .replace('stx', 'šć') \
        .replace('zdx', 'žđ') \
        .replace('sx', 'š') \
        .replace('šx', 'š') \
        .replace('zx', 'ž') \
        .replace('žx', 'ž') \
        .replace('cx', 'č') \
        .replace('čx', 'č') \
        .replace('tx', 'ć') \
        .replace('dx', 'đ') \
        .replace('jx', 'j') \
        .replace('x', 'j') \
        .replace('-', '') \
        .replace('—', '-') \
        .replace('lı', 'ľ') \
        .replace('nı', 'ń') \
        .replace('rı', 'ŕ') \
        .replace('tı', 'ť') \
        .replace('dı', 'ď') \
        .replace('sı', 'ś') \
        .replace('zı', 'ź') \
        .replace('ı', '')
